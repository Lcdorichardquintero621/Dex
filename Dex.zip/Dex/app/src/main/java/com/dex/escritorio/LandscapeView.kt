package com.dex.escritorio

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import kotlin.math.sin

/** Fondo de escritorio dibujado por código: cielo, nubes, montañas, colinas y pinos. */
class LandscapeView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        p.shader = LinearGradient(
            0f, 0f, 0f, h * 0.65f,
            intArrayOf(0xFF2E86D6.toInt(), 0xFF9ED8F6.toInt()), null, Shader.TileMode.CLAMP
        )
        cv.drawRect(0f, 0f, w, h, p)
        p.shader = null

        p.color = 0xDDFFFFFF.toInt()
        cloud(cv, w * 0.18f, h * 0.16f, h * 0.05f)
        cloud(cv, w * 0.72f, h * 0.24f, h * 0.06f)
        cloud(cv, w * 0.46f, h * 0.10f, h * 0.035f)

        ridge(cv, w, h, 0.50f, h * 0.20f, 0xFF4F6FB0.toInt(), 1)
        ridge(cv, w, h, 0.58f, h * 0.16f, 0xFF6B8FC9.toInt(), 4)

        hill(cv, w, h, 0.64f, h * 0.08f, 0xFF7BD34A.toInt(), 0xFF2F9E2F.toInt())
        hill(cv, w, h, 0.78f, h * 0.07f, 0xFF4FBF2B.toInt(), 0xFF1F7A22.toInt())

        for (i in 0..6) {
            val y = h * (0.82f + (i % 3) * 0.045f)
            tree(cv, w * (0.02f + i * 0.028f), y, h * (0.05f + (i % 2) * 0.012f))
            tree(cv, w * (0.98f - i * 0.028f), y, h * (0.05f + ((i + 1) % 2) * 0.012f))
        }
    }

    private fun cloud(cv: Canvas, cx: Float, cy: Float, r: Float) {
        cv.drawOval(RectF(cx - r * 2.2f, cy - r * 0.6f, cx + r * 2.2f, cy + r * 0.8f), p)
        cv.drawCircle(cx - r * 0.7f, cy - r * 0.2f, r, p)
        cv.drawCircle(cx + r * 0.6f, cy - r * 0.35f, r * 1.2f, p)
    }

    private fun ridge(cv: Canvas, w: Float, h: Float, base: Float, amp: Float, color: Int, seed: Int) {
        path.reset()
        path.moveTo(0f, h)
        val steps = 10
        for (i in 0..steps) {
            val x = w * i / steps
            val k = if (i % 2 == 0) 1f else 0.55f
            val y = h * base - amp * (0.5f + 0.5f * sin(i * 1.7f + seed)) * k
            path.lineTo(x, y)
        }
        path.lineTo(w, h)
        path.close()
        p.color = color
        cv.drawPath(path, p)
    }

    private fun hill(cv: Canvas, w: Float, h: Float, base: Float, amp: Float, top: Int, bottom: Int) {
        path.reset()
        path.moveTo(0f, h)
        path.lineTo(0f, h * base)
        path.cubicTo(w * 0.25f, h * base - amp, w * 0.55f, h * base + amp * 0.6f, w, h * base - amp * 0.4f)
        path.lineTo(w, h)
        path.close()
        p.shader = LinearGradient(0f, h * base - amp, 0f, h, top, bottom, Shader.TileMode.CLAMP)
        cv.drawPath(path, p)
        p.shader = null
    }

    private fun tree(cv: Canvas, x: Float, y: Float, s: Float) {
        p.color = 0xFF5B3A1E.toInt()
        cv.drawRect(x - s * 0.06f, y - s * 0.2f, x + s * 0.06f, y, p)
        p.color = 0xFF14532D.toInt()
        for (i in 0..2) {
            val top = y - s * (0.3f + i * 0.55f) - s * 0.6f
            val bot = y - s * (0.3f + i * 0.55f) + s * 0.25f
            val half = s * (0.5f - i * 0.1f)
            path.reset()
            path.moveTo(x, top)
            path.lineTo(x - half, bot)
            path.lineTo(x + half, bot)
            path.close()
            cv.drawPath(path, p)
        }
    }
}
